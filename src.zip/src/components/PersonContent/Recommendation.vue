<template>
    <div style="width:100%;height:1000px;border:2px solid black">
        Recommendation
    </div>
</template>

<script>
export default {
  name: "Recommendation"
};
</script>

<style scoped>
</style>
