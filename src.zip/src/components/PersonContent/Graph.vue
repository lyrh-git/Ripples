<template>
  <div class="graph">
        <div class="top">
      <p class="title">情绪曲线</p>
      <div class="thread"></div>
    </div>
    <div class="message">
    <div id="chart1" style="width:600px;height:400px"></div>    
    <div id="chart2" style="width:400px;height:300px"></div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Graph",
  data(){
    return{
      chart1:null,
      chart2:null,
    }
  },
  mounted(){
    this.initChart1();
    this.initChart2();

  },
  methods:{
    initChart1:function(){
        this.chart1 = this.$echarts.init(document.getElementById("chart1"));
        // 指定图表的配置项和数据
        var option = {
            title: {
                text: '一周情绪曲线'
            },
            tooltip: {},
            legend: {
                data: ['情绪值']
            },
            xAxis: {
                data: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
            },
            yAxis: {},
            series: [{
                name: '情绪值',
                type: 'line',
                data: [5, 20, 36, 10, 10, 20, 31]
            }]
        };
        // 使用刚指定的配置项和数据显示图表。
      this.chart1.setOption(option);
    },
    initChart2:function(){
      
        this.chart2 = this.$echarts.init(document.getElementById("chart2"));
        var dataMon = [
            [42, 16, 50, 83, 94, 5, 61],
        ];
        var dataTue = [
            [51, 26, 18, 7, 95, 49, 67],
        ];
        var dataWed = [
            [12, 23, 34, 45, 56, 67, 78],
        ];
        var dataThu = [
            [8, 16, 24, 40, 80, 57, 39],
        ];
        var dataFri = [
            [90, 60, 53, 43, 26, 95, 16],
        ];
        var dataSat = [
            [21, 52, 90, 61, 73, 71, 80],
        ];
        var dataSun = [
            [78, 89, 64, 2, 13, 45, 10],
        ];
        var lineStyle = {
            normal: {
                width: 1,
                opacity: 0.6
            }
        };
        var option = {           
            backgroundColor: '#161627',
            title: {
                text: '一周情绪值分布',
                left: 'center',
                textStyle: {
                    color: '#eee'
                }
            },
            legend: {
                bottom: 10,//选项距离底部的宽度
                data: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
                itemGap: 30,
                textStyle: {
                    color: '#fff',
                    fontSize: 20
                },
                selectedMode: 'double'
            },
            radar: {
                indicator: [
                    {name: '乐', max: 100},
                    {name: '好', max: 100},
                    {name: '怒', max: 100},
                    {name: '哀', max: 100},
                    {name: '惧', max: 100},
                    {name: '恶', max: 100},
                    {name: '惊', max: 100}
                ],
                shape: 'circle',
                splitNumber: 5,
                name: {
                    textStyle: {
                        color: '#FFFFFF',
                        fontSize: 14
                    }
                },
                splitLine: {
                    lineStyle: {
                        color: [
                            'rgba(255, 255, 255, 0.1)', 'rgba(255, 255, 255, 0.2)',
                            'rgba(255, 255, 255, 0.4)', 'rgba(255, 255, 255, 0.6)',
                            'rgba(255, 255, 255, 0.8)', 'rgba(255, 255, 255, 1)'
                        ].reverse()
                    }
                },
                splitArea: {
                    show: false
                },
                axisLine: {
                    lineStyle: {
                        color: 'rgba(255, 255, 255, 0.5)'
                    }
                }
            },
            series: [
                {
                    name: 'Mon',
                    type: 'radar',
                    lineStyle: lineStyle,
                    data: dataMon,
                    symbol: 'none',
                    itemStyle: {
                        color: 'red'
                    },
                    areaStyle: {
                        opacity: 0.1
                    }
                },
                {
                    name: 'Tue',
                    type: 'radar',
                    lineStyle: lineStyle,
                    data: dataTue,
                    symbol: 'none',
                    itemStyle: {
                        color: 'orange'
                    },
                    areaStyle: {
                        opacity: 0.1
                    }
                },
                {
                    name: 'Wed',
                    type: 'radar',
                    lineStyle: lineStyle,
                    data: dataWed,
                    symbol: 'none',
                    itemStyle: {
                        color: 'yellow'
                    },
                    areaStyle: {
                        opacity: 0.1
                    }
                },
                {
                    name: 'Thu',
                    type: 'radar',
                    lineStyle: lineStyle,
                    data: dataThu,
                    symbol: 'none',
                    itemStyle: {
                        color: 'green'
                    },
                    areaStyle: {
                        opacity: 0.1
                    }
                },
                {
                    name: 'Fri',
                    type: 'radar',
                    lineStyle: lineStyle,
                    data: dataFri,
                    symbol: 'none',
                    itemStyle: {
                        color: 'cyan'
                    },
                    areaStyle: {
                        opacity: 0.1
                    }
                },
                {
                    name: 'Sat',
                    type: 'radar',
                    lineStyle: lineStyle,
                    data: dataSat,
                    symbol: 'none',
                    itemStyle: {
                        color: 'blue'
                    },
                    areaStyle: {
                        opacity: 0.1
                    }
                },
                {
                    name: 'Sun',
                    type: 'radar',
                    lineStyle: lineStyle,
                    data: dataSun,
                    symbol: 'none',
                    itemStyle: {
                        color: 'purple'
                    },
                    areaStyle: {
                        opacity: 0.1
                    }
                },
            ]
                };
        
      this.chart2.setOption(option);
    }
  }
};
</script>

<style scoped>
.graph {
  padding: 20px;
  width:95%;
  overflow:hidden;
}

.top {
  /* width: 95%; */
}
.title {
  font-size: 25px;
  font-weight: 600;
}
.thread {
  position: relative;
  /* left:150px; */
  border-top: 1px solid black;
  margin-top: 10px;
}

.message {
  margin-top: 20px;
}
</style>
