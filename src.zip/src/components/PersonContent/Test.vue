<template>
  <div class="test">
    <div class="top">
      <p class="title">测试</p>
      <div class="thread"></div>
    </div>
    <div class="message">
      <div v-for="test in tests" class="eachTest">
        <div style="text-align:left;">
          <a :href="test.href" class="test_title" target="_blank">{{test.title}}</a>
        </div>
        <div class="brief">{{test.brief}}</div>
      </div>
    </div>

  </div>
</template>

<script>
export default {
  name: "Test",
  data() {
    return {
      tests: [
        {
          title: "性格测试",
          brief: "来测测你是什么性格",
          href: "http://www.baidu.com"
        },
        {
          title: "焦虑测试",
          brief: "来测测你有多焦虑",
          href: "http://www.baidu.com"
        }
      ]
    };
  }
};
</script>

<style scoped>
.test {
  padding: 20px;
  width: 95%;
}
.top .title {
  font-size: 25px;
  font-weight: 600;
}

.thread {
  position: relative;
  /* left:150px; */
  border-top: 1px solid black;
  margin-top: 10px;
  width: 95%;
}

.message {
  margin-top: 40px;
}
.eachTest {
  margin-bottom: 30px;
}
.test_title {
  color: black;
  font-size: 20px;
  font-weight: 600;
}
.test_title:hover {
  cursor: pointer;
  color: royalblue;
}
.brief {
  color: grey;
  font-size: 16px;
  margin-top: 15px;
  text-align: left;
}
</style>
