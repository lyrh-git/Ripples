//存放配置项（商品信息）

export default {
    goods:[
        {
            name:'平衡',
            brief:'没事儿就盯着它看吧。办公室解压神器男生抖音网红女生的小减压黑科技平衡玩具成年发泄',
            image:'/static/images_shop/calm/budaoweng.jpg',
            href:"https://item.taobao.com/item.htm?id=570875041990&ali_refid=a3_430673_1006:1103986462:N:xmp1sgfl40nWcXQveHMwn5oPnOGEz5NP:0e9d2ea6db7018692596ee002afd6be5&ali_trackid=1_0e9d2ea6db7018692596ee002afd6be5&spm=a2e15.8261149.07626516002.100"
        },
        {
            name:'韩国刀刻书',
            brief:'这刻出来真的很好看。韩国刀刻书DIY手工制作个性雕刻画纸雕书男女闺蜜创意生日礼物品',
            image:'/static/images_shop/relief/zhidiao.jpg',
            href:"http://www.baidu.com"
        },
        {
            name:'小黄鸭',
            brief:'谁还不是个小公举啊！婴儿玩具大小黄鸭小鸭子捏捏叫宝宝洗澡戏水男孩女孩捏响玩具浴室',
            image:'/static/images_shop/outlet/xiaohuangya.jpg',
            href:"https://item.taobao.com/item.htm?id=565039482327&ali_refid=a3_430673_1006:1123889575:N:shde4nbYLE2tQbyNwlkWlg%3D%3D:7735c8c9808bbe2976958575651a10c1&ali_trackid=1_7735c8c9808bbe2976958575651a10c1&spm=a2e15.8261149.07626516002.9"
        },
    ]

}