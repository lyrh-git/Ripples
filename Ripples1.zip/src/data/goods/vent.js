//存放配置项（商品信息）

export default {
    goods:[
        {
            name:'方便面',
            brief:'可吃可捏。南街村老北京方便面河南特产整箱袋装泡面65g麻辣包邮干吃干脆面',
            image:'/static/images_shop/outlet/fangmianmian.jpg',
            href:"https://item.taobao.com/item.htm?spm=a1z09.2.0.0.23c72e8dUP9YVs&id=40089188669&_u=m35v4aphf124"
        },
        {
            name:'飞镖',
            brief:'瞄准敌人就是一个爆头。室内射击靶子比赛专用专业18寸成人大号盘带针飞标靶套装训练',
            image:'/static/images_shop/outlet/feibiao.jpg',
            href:"https://item.taobao.com/item.htm?spm=a1z09.2.0.0.23c72e8dUP9YVs&id=550760503292&_u=m35v4aphdf65"
        },
        {
            name:'小黄鸭',
            brief:'谁还不是个小公举啊！婴儿玩具大小黄鸭小鸭子捏捏叫宝宝洗澡戏水男孩女孩捏响玩具浴室',
            image:'/static/images_shop/outlet/xiaohuangya.jpg',
            href:"https://item.taobao.com/item.htm?id=565039482327&ali_refid=a3_430673_1006:1123889575:N:shde4nbYLE2tQbyNwlkWlg%3D%3D:7735c8c9808bbe2976958575651a10c1&ali_trackid=1_7735c8c9808bbe2976958575651a10c1&spm=a2e15.8261149.07626516002.9"
        },
        
    ]

}