//存放配置项（商品信息）

export default {
    goods:[
        {
            name:'弦丝画',
            brief:'图形自定n种排列组合。弦丝画钉子画绿植摆件减压手工绕线画diy材料包消磨时间创意礼',
            image:'/static/images_shop/relief/xiansihua.jpg',
            href:"https://item.taobao.com/item.htm?id=612763566559&ali_refid=a3_430673_1006:1207950098:N:oGduVt4c%2FDwle0MqBS7dyg%3D%3D:c84228a0d1a6175098ec51464c123cd2&ali_trackid=1_c84228a0d1a6175098ec51464c123cd2&spm=a2e15.8261149.07626516002.5"
        },
        {
            name:'解锁解环',
            brief:'接受考验的时候到了。九连环益智玩具25件套装成人智力扣高智商孔明锁解锁儿童烧脑解环',
            image:'/static/images_shop/relief/jiehuan.jpg',
            href:"https://item.taobao.com/item.htm?id=574011940915&ali_refid=a3_430673_1006:1110257357:N:EJipSAb3HbB0Cz%2Bg%2BKTenw%3D%3D:c949e1e353d9f785dcb96aaa8fb20dfd&ali_trackid=1_c949e1e353d9f785dcb96aaa8fb20dfd&spm=a2e15.8261149.07626516002.4"
        },
        {
            name:'韩国刀刻书',
            brief:'这刻出来真的很好看。韩国刀刻书DIY手工制作个性雕刻画纸雕书男女闺蜜创意生日礼物品',
            image:'/static/images_shop/relief/zhidiao.jpg',
            href:"http://www.baidu.com"
        },
        
    ]

}