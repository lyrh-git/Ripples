<template>
  <div>
    <div style="width:100%;height:3000px;border:2px solid black">
      This is introduction
      </div>
  </div>
</template>

<script>
export default {
  name: "toolbars",

  
}
</script>

<style scoped>

.toolbars{
	position: fixed;
	top: 0;
	right: 0;
	height: 100%;
	width: 6px;
	background-color: #7a6e6e;
}
.toolbars ul{
  	position:absolute;
  	top: 50%;
  	right: 0;
  	transform: translate(0,-40%);
  	z-index: 3;
}
.toolbars ul li{
	width: 34px;
	height: 35px;
	margin-bottom: 2px;
	background-color: #7A6E6E;
	position: relative;
}
.toolbars ul .jdvip .toolbars-ico{
	display: block;
	width: 34px;
	height: 35px;
	background: url(../img/toolbars.png)no-repeat -88px -175px;
}
.toolbars ul .cart .toolbars-ico{
	display: block;
	width: 34px;
	height: 35px;
	background: url(../img/toolbars.png)no-repeat -50px 0;
}
.toolbars ul .follow .toolbars-ico{
	display: block;
	width: 34px;
	height: 35px;
	background: url(../img/toolbars.png)no-repeat -50px -50px;
}
.toolbars ul .message .toolbars-ico{
	display: block;
	width: 34px;
	height: 35px;
	background: url(../img/toolbars.png)no-repeat -190px -150px;
}
.toolbars ul .jimi .toolbars-ico{
	display: block;
	width: 34px;
	height: 35px;
	background: url(../img/toolbars.png)no-repeat -50px -150px;
}
.toolbars ul .feedback .toolbars-ico{
	display: block;
	width: 34px;
	height: 35px;
	background: url(../img/toolbars.png)no-repeat -50px -300px;
}
.toolbars ul .jdvip i{
	position: absolute;
    top: 5px;
    right: 8px;
	width: 6px;
	height: 6px;
	background: url(../img/toolbars.png)no-repeat -150px -150px;	
}
.toolbars-footer{
	position: absolute;
	bottom: 0;
	right: 0;
	background-color: #7A6E6E;
	width: 34px;
	height: 35px;
	z-index: 3;
}
.toolbars-footer .toolbars-ico{
	display: block;
	width: 34px;
	height: 35px;
	background: url(../img/toolbars.png)no-repeat -50px -250px;
}
	/*鼠标悬浮后伸出的部分*/
.toolbars .flex{
	position: absolute;
	top: 0;
	right: 34px;
	width: 0;
	overflow: hidden;
	height: 35px;
	line-height: 35px;
	background-color: #b61d1d;
	text-align: center;	
	color: #fff;
	z-index: -1;
	transition: width .3s;
}
	/*鼠标悬浮后的效果*/
.toolbars ul li:hover{
	background-color: #b61d1d;
}
.toolbars ul li:hover .flex{
	width: 62px;
	background-color: #b61d1d;
}
.toolbars ul li:hover i{
	display: none;
}
.toolbars-footer:hover{
	background-color: #b61d1d;
}
.toolbars-footer:hover .flex{
	width: 62px;
	background-color: #b61d1d;
}

</style>